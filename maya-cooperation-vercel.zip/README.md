# MAYA COOPERATION STARK — Vercel

## Deploy
1. Upload/push folder ini ke GitHub.
2. Import repository ke Vercel.
3. Di Vercel → Settings → Environment Variables, tambahkan:
   - `DISCORD_WEBHOOK_URL`
   - `WHATSAPP_NUMBER`
4. Redeploy.

## Penting
Jangan menaruh Discord Webhook URL di `public/index.html`.
Website mengirim order ke `/api/order`, lalu Vercel Function meneruskan order + slip ke Discord.

## QRIS & produk
Edit `public/index.html`:
- `QRIS_URL` untuk URL gambar QRIS.
- `products` untuk nama, harga, dan gambar produk.

## Catatan
Versi ini mengirim slip langsung dari browser ke Vercel Function sebagai base64 lalu meneruskannya ke Discord. Untuk file besar/volume tinggi, gunakan object storage seperti Cloudinary/S3 dan kirim URL file ke backend.
